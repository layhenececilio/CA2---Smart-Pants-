/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca2layhene;

/**
 *
 * @author layhenececilio
 */
public class CA2Layhene {
    static void Layhene() {
        /**author:L. Prado
         * 
         */
        System.out.println("This is Layhene's code.");
        System.out.println("This is my mean code.");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Layhene();
            int n1 = 25;    // I prefer to creat 2 int so if the user of the code wants to change for a specific sum it's more flexible.
            int n2 = 85;
                System.out.println("The sum of " + n1 + " and " + n2 + " = " + (n1+n2));
    }
    
}
